<?php



$username = "root";
$password = '';
$dbname='donate';
$sname = 'localhost';
$conn = new mysqli($sname,$username, $password,$dbname );

?>